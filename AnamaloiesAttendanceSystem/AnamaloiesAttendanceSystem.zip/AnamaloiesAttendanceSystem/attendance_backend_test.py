import streamlit as st
import cv2
import numpy as np
import os
import sys
import pandas as pd
import tempfile
import shutil
from typing import List

# --- Configuration & Module Setup ---
sys.path.append(os.path.dirname(__file__))

try:
    import TableExtractor as te
    import TableLinesRemover as tlr
    import OCRToTableTool as ottt
    # Define StudentRecord type alias for clarity
    StudentRecord = ottt.StudentRecord
except ImportError as e:
    st.error(f"Failed to import core modules. Ensure all Python files are in the same directory: {e}")
    sys.exit()

# Set up necessary directories for file-based processing
TEMP_DIR_ROOT = "streamlit_temp"

def setup_directories(temp_root):
    """Creates all necessary directories for the pipeline's output files."""
    os.makedirs(os.path.join(temp_root, "processed_images/table_extractor/"), exist_ok=True)
    os.makedirs(os.path.join(temp_root, "processed_images/table_lines_remover/"), exist_ok=True)
    os.makedirs(os.path.join(temp_root, "processed_images/ocr_table_tool/"), exist_ok=True)
    os.makedirs("Output_Reports/", exist_ok=True)
    os.makedirs("ocr_slices", exist_ok=True)

def cleanup_directories(temp_root):
    """Removes temporary directories to clean up after the run."""
    try:
        shutil.rmtree(temp_root)
        shutil.rmtree("ocr_slices") 
        shutil.rmtree("Output_Reports")
    except Exception:
        pass

# --- NEW DATA FILTERING FUNCTION ---
def filter_valid_records(records: List[StudentRecord]) -> List[StudentRecord]:
    """Filters out records that are completely empty or malformed at the start."""
    valid_records = []
    for record in records:
        # Check if the primary identification fields are all empty or whitespace
        if record.student_id.strip() or record.student_name.strip() or record.status.strip():
            valid_records.append(record)
    return valid_records
# --- END NEW DATA FILTERING FUNCTION ---

# --- ANALYTICS FUNCTION ---
def calculate_attendance_analytics(structured_data: List[StudentRecord], threshold: float = 0.75):
    """
    Calculates attendance percentage (based on 'P' marks) and identifies defaulters.
    """
    results = []
    all_dates = sorted(set(d for s in structured_data for d in s.attendance_dates.keys()))
    total_days = len(all_dates)

    if total_days == 0:
        return pd.DataFrame(), {'defaulters': 0, 'total_students': len(structured_data)}
        
    for student in structured_data:
        present_count = 0
        
        for mark in student.attendance_dates.values():
            if mark.upper() == 'P':
                present_count += 1
        
        percentage = (present_count / total_days) * 100
        status = 'Defaulter' if percentage < (threshold * 100) else 'Normal'
        
        results.append({
            'Roll No / Student ID': student.student_id,
            'Student Name': student.student_name,
            'Source Status': student.status,
            'Attendance (%)': percentage,
            'Attendance Status (Defaulter)': status
        })

    df_analytics = pd.DataFrame(results)
    defaulter_count = df_analytics['Attendance Status (Defaulter)'].value_counts().get('Defaulter', 0)
    
    return df_analytics, {
        'defaulters': defaulter_count, 
        'total_students': len(structured_data)
    }

# --- PROCESS DOCUMENT FUNCTION (FIXED WITH DEBUG MOCK AND FILTERING) ---
def process_document(uploaded_image_cv2, file_name):
    """Executes the full pipeline flow, inserting a debug mock if OCR fails, and filtering output."""
    
    cleanup_directories(TEMP_DIR_ROOT)
    setup_directories(TEMP_DIR_ROOT)

    path_to_image = os.path.join(TEMP_DIR_ROOT, file_name)
    cv2.imwrite(path_to_image, uploaded_image_cv2)

    structured_data: List[StudentRecord] = []
    csv_output = ""
    
    try:
        # 1. Pipeline Execution
        table_extractor = te.TableExtractor(path_to_image)
        perspective_corrected_image = table_extractor.execute()

        lines_remover = tlr.TableLinesRemover(perspective_corrected_image)
        image_without_lines = lines_remover.execute()

        ocr_tool = ottt.OcrToTableTool(image_without_lines, perspective_corrected_image)
        ocr_tool.execute()
        
        # 2. Retrieve Results
        structured_data = ocr_tool.table

        # Read the generated CSV content
        csv_path = "Output_Reports/output.csv"
        if os.path.exists(csv_path):
            with open(csv_path, "r", encoding='utf-8') as f:
                csv_output = f.read()

        st.session_state['perspective_corrected_image'] = cv2.cvtColor(perspective_corrected_image, cv2.COLOR_BGR2RGB)
        st.session_state['image_without_lines'] = cv2.cvtColor(image_without_lines, cv2.COLOR_BGR2RGB)

        st.success("Document processing completed!")
        
    except Exception as e:
        st.error(f"An error occurred during pipeline execution: {e}")
        st.warning("Using Debug Sample Data to verify Streamlit structure.")
        
    finally:
        # --- DEBUG MOCK INJECTION (To guarantee structure display on failure) ---
        if not structured_data:
            sample_records = [
                ottt.StudentRecord(
                    student_id='D101', 
                    student_name='DEBUG_Alice Smith', 
                    status='P', 
                    attendance_dates={'2023-10-01': 'P', '2023-10-02': 'A', '2023-10-03': 'AB'}
                ),
                ottt.StudentRecord(
                    student_id='D102', 
                    student_name='DEBUG_Bob Johnson', 
                    status='AB', 
                    attendance_dates={'2023-10-01': 'A', '2023-10-02': 'P', '2023-10-03': 'P'}
                ),
                # This simulates a junk row that needs filtering
                ottt.StudentRecord(
                    student_id=' ', 
                    student_name='   ', 
                    status='', 
                    attendance_dates={'2023-10-01': '', '2023-10-02': '', '2023-10-03': ''}
                ),
            ]
            structured_data = sample_records
            csv_output = "ID,Name,Status,Date1,Date2\nD101,Alice,P,P,A\nD102,Bob,AB,A,P"
        
        # --- CRITICAL FIX: FILTERING ---
        structured_data = filter_valid_records(structured_data)

        st.session_state['structured_data'] = structured_data
        st.session_state['csv_output'] = csv_output
        cleanup_directories(TEMP_DIR_ROOT)


# --- Streamlit UI Components ---

st.set_page_config(
    page_title="Attendance Table OCR System",
    layout="wide",
    initial_sidebar_state="expanded"
)

st.title("📚 Attendance Table OCR and Structuring")
st.markdown("Upload an image of an attendance sheet to extract student records and attendance data.")

# Initialize session state
if 'structured_data' not in st.session_state:
    st.session_state['structured_data'] = None
if 'csv_output' not in st.session_state:
    st.session_state['csv_output'] = None


# File Uploader in the sidebar
with st.sidebar:
    st.header("Upload Image")
    uploaded_file = st.file_uploader("Choose an image file", type=["jpg", "jpeg", "png"])
    
    if uploaded_file is not None:
        st.subheader("Process")
        file_bytes = np.asarray(bytearray(uploaded_file.read()), dtype=np.uint8)
        initial_image_cv2 = cv2.imdecode(file_bytes, cv2.IMREAD_COLOR)
        
        st.image(initial_image_cv2, channels="BGR", caption="Original Uploaded Image", use_column_width=True)
        
        if st.button("Start OCR Processing"):
            st.session_state['csv_output'] = None 
            st.session_state['structured_data'] = None 

            with st.spinner('Processing image...'):
                process_document(initial_image_cv2, uploaded_file.name)
    else:
        st.info("Please upload an image to start the process.")

# --- Main Content Area: Results Display ---

if st.session_state.get('structured_data') is not None and st.session_state['structured_data']:
    st.header("✅ Processing Results")
    
    # 1. RUN ANALYTICS
    df_analytics, counts = calculate_attendance_analytics(st.session_state['structured_data'])

    # 2. DISPLAY SUMMARY COUNT (Anomalies/Defaulters)
    st.subheader("Attendance Summary (Defaulter Threshold: 75%)")
    col1, col2, col3 = st.columns(3)
    col1.metric("Total Students", counts['total_students'])
    col2.metric("Defaulters (< 75%)", counts['defaulters'])
    col3.metric("Defaulter Percentage", f"{(counts['defaulters'] / counts['total_students']) * 100:.2f}%" if counts['total_students'] else "0.00%")
    
    st.divider()

    # 3. DISPLAY FULL ANALYTICS TABLE (including percentage)
    st.subheader("Attendance Analytics and Status")
    st.dataframe(
        df_analytics.style.format({'Attendance (%)': "{:.2f}%"}), 
        use_container_width=True, 
        hide_index=True
    )
    
    st.divider()
    
    # 4. DISPLAY RAW EXTRACTED TABLE DATA (The requested structure: ID, Name, Status, P/A Marks)
    st.subheader("Raw Extracted Table Data (Attendance Marks)")
    
    try:
        all_dates = sorted(set(d for s in st.session_state['structured_data'] for d in s.attendance_dates.keys()))
        
        # Structure as requested: ID, Name, Status, then Date columns (containing P/A marks)
        column_names = ['Roll No / Student ID', 'Student Name', 'Status'] + all_dates
        
        df_data = [
            [s.student_id, s.student_name, s.status] + 
            [s.attendance_dates.get(h, '') for h in all_dates]
            for s in st.session_state['structured_data']
        ]

        df_raw = pd.DataFrame(df_data, columns=column_names)
        st.dataframe(df_raw, use_container_width=True, hide_index=True)
        
    except Exception as e:
        st.error(f"Could not display raw structured data: {e}")

    # 5. DOWNLOAD CSV
    st.download_button(
        label="Download Original Extracted Data as CSV",
        data=st.session_state.get('csv_output', ""),
        file_name='attendance_report.csv',
        mime='text/csv',
    )
    
    st.divider()

    # 6. DISPLAY INTERMEDIATE IMAGES
    st.header("🖼️ Intermediate Processing Steps")

    with st.expander("Show Visualization of Steps"):
        col1, col2 = st.columns(2)
        
        if st.session_state.get('perspective_corrected_image') is not None:
            col1.image(st.session_state['perspective_corrected_image'], 
                       caption="1. Perspective Correction (Table Extractor)", 
                       use_column_width=True, channels="RGB")
        
        if st.session_state.get('image_without_lines') is not None:
            col2.image(st.session_state['image_without_lines'], 
                       caption="2. Table Lines Removed (Lines Remover)", 
                       use_column_width=True, channels="RGB")

        st.info("The final OCR step uses the line-removed image to extract data and build the table above.")